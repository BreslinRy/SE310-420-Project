#pragma once
class Receipt
{
public:
	Receipt();
	~Receipt();
};

