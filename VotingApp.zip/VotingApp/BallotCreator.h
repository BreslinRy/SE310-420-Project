#pragma once
class BallotCreator
{
public:
	BallotCreator();
	~BallotCreator();
	void addDatabaseElement();
	void getBallot();
	void ballotDisplay();

};

