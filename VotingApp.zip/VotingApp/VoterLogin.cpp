#include "VoterLogin.h"
#include "DatabaseConnector.h"


VoterLogin::VoterLogin()
{
}


VoterLogin::~VoterLogin()
{
}

void VoterLogin::login()
{
}
