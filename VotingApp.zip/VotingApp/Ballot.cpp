#include "Ballot.h"
#include "DatabaseConnector.h"


Ballot::Ballot()
{
}


Ballot::~Ballot()
{
}

void Ballot::ballotSelection()
{
}

void Ballot::getSelection()
{
}

void Ballot::selectionAppoval()
{
}
