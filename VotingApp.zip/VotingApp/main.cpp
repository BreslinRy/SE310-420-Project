#include "AdminGUI.h"
#include "BallotGUI.h"

int main() {
}