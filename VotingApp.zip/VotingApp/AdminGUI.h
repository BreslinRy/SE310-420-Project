#pragma once
class AdminGUI
{
public:
	AdminGUI();
	~AdminGUI();
	void getExampleBallot(); 
};

