#pragma once

class BallotGUI
{
public:
	BallotGUI();
	~BallotGUI();
	void launchBallot(); 
};

