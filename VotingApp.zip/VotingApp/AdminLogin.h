#pragma once
class AdminLogin
{
public:
	AdminLogin();
	~AdminLogin();
	void login();

};

