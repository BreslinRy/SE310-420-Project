#pragma once
class Ballot
{
public:
	Ballot();
	~Ballot();
	void ballotSelection();
	void getSelection();
	void selectionAppoval(); 
};

