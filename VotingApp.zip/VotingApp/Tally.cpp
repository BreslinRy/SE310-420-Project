#include "Tally.h"
#include "DatabaseConnector.h"


Tally::Tally()
{
}


Tally::~Tally()
{
}

void Tally::getTally()
{
}
