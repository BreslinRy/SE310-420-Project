#pragma once
class VoterLogin
{
public:
	VoterLogin();
	~VoterLogin();
	void login(); 
};

