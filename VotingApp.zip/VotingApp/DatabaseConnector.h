#pragma once
class DatabaseConnector
{
public:
	DatabaseConnector();
	~DatabaseConnector();
};

