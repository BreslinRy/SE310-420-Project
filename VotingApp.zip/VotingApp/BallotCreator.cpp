#include "BallotCreator.h"
#include "DatabaseConnector.h"


BallotCreator::BallotCreator()
{
}


BallotCreator::~BallotCreator()
{
}

void BallotCreator::addDatabaseElement()
{
}

void BallotCreator::getBallot()
{
}

void BallotCreator::ballotDisplay()
{
}
