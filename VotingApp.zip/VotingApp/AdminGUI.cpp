#include "AdminGUI.h"
#include "AdminLogin.h"
#include "BallotCreator.h"
#include "OfficalRecord.h"
#include "ResultSender.h"
#include "Tally.h"


AdminGUI::AdminGUI()
{
}


AdminGUI::~AdminGUI()
{
}

void AdminGUI::getExampleBallot()
{
}
