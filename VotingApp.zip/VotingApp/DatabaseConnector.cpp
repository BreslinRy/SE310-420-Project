#include "DatabaseConnector.h"



DatabaseConnector::DatabaseConnector()
{
}


DatabaseConnector::~DatabaseConnector()
{
}
