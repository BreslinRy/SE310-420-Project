#include "OfficalRecord.h"
#include "DatabaseConnector.h"


OfficalRecord::OfficalRecord()
{
}


OfficalRecord::~OfficalRecord()
{
}
