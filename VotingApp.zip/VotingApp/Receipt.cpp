#include "Receipt.h"
#include "DatabaseConnector.h"


Receipt::Receipt()
{
}


Receipt::~Receipt()
{
}
