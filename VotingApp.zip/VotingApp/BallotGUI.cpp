#include "BallotGUI.h"
#include "Ballot.h"
#include "Receipt.h"
#include "VoterLogin.h"


BallotGUI::BallotGUI()
{
}


BallotGUI::~BallotGUI()
{
}

void BallotGUI::launchBallot()
{
}
