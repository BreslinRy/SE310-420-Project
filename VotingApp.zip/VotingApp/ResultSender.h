#pragma once
class ResultSender
{
public:
	ResultSender();
	~ResultSender();
};

