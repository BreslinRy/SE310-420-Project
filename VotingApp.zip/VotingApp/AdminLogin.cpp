#include "AdminLogin.h"
#include "DatabaseConnector.h"


AdminLogin::AdminLogin()
{
}


AdminLogin::~AdminLogin()
{
}

void AdminLogin::login()
{
}
