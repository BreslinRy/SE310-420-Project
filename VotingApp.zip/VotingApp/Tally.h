#pragma once
class Tally
{
public:
	Tally();
	~Tally();
	void getTally();
};

