#include "ResultSender.h"



ResultSender::ResultSender()
{
}


ResultSender::~ResultSender()
{
}
