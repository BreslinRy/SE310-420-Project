#pragma once
class OfficalRecord
{
public:
	OfficalRecord();
	~OfficalRecord();
};

